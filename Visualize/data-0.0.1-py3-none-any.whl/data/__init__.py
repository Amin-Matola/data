from . import app, processor

def boot():
	app.App.boot()