from app import App

App.boot()